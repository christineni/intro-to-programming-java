/******************************************************************
 * Program or Assignment #: Lab1
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 21, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will take two declared integers and
 * 				calculate the sum and product of the two numbers.
 * 				It will then print out the four numbers on the screen.
 *
 * Input:  Two numbers of integer type.
 *
 * Output:  The program will print the two original integers, the sum
 * 			of the two integers, and the product of the two integers.
 *
 ******************************************************************/


public class Integer {
	public static void main(String[] args) {
		int num1 = 3;
		int num2 = 5;
		int sum = num1 + num2;
		int product = num1 * num2;
		
		System.out.println("The first number is " + num1);
		System.out.println("The second number is " + num2);
		System.out.println("The sum of the two numbers is " + sum);
		System.out.println("The product of the two numbers is " + product);
	}
	
}
