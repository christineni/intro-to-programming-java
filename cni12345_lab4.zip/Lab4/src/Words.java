/******************************************************************
 * Program or Assignment #: Lab4
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 24, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program prompts the user to enter a word beginning
 * 				in capital A or B. The program will check to see if the 
 * 				user entered the correctly as well the length.
 *
 * Input:  A word beginning in "A" or "B"
 *
 * Output:  If the word starts with "A" or "B", the program will print
 * 			"You correctly printed the word". If the word starts with "C", 
 * 			it will print "close, but no cigar". If its none of the above,
 * 			it will tell you that you incorrectly printed the word.
 * 			If the word is less than or equal to five letter, it will tell
 * 			that it is a short word. If it's more, then it will tell the 
 * 			user it is a long word. * 			 
 *
 ******************************************************************/

import java.util.Scanner;

public class Words {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Input a word beginning with capital A or B");
		String s1 = s.nextLine();
		if (s1.startsWith("A") || s1.startsWith("B")) {
			System.out.println("You correctly printed the word");
		}
		else if (s1.startsWith("C")) {
			System.out.println("Close, but no cigar.");
		}
		else {
			System.out.println("You incorrectly printed the word");
		}
		if (s1.length() <= 5){
			System.out.println("You printed a short word.");
		}
		else {
			System.out.println("You printed a long word.");
		}
	}
}
	
