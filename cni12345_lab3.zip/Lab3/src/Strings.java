/******************************************************************
 * Program or Assignment #: Lab3
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 21, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will ask the user to declare two strings. 
 * 				The two strings will be concatenated in a new
 * 				variable, printed to the screen, then the length of 
 * 				the string will be printed to the screen. Then the 
 * 				character 'S' will be printed to the screen and then 
 * 				the entire concatenated string will be changed to 
 * 				all lower case and printed to the string.
 * 
 * Input:  Two strings
 *
 * Output:  The program will print the value for the two strings
 * 			concatenated, the length of the concatenated string,
 * 			the character 'S', and the concatenated string in all
 * 			lower case.
 ******************************************************************/

public class Strings {
	public static void main(String[] args) {
		String s1 = "Computer Science";
		String s2 = " is fun!";
		String s3 = (s1) + (s2);
		
		System.out.println(s3);
		System.out.println(s3.length());
		System.out.println(s3.charAt(9));
		System.out.println(s3.toLowerCase());
	}

}
