/******************************************************************
 * Program or Assignment #: Lab6
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 24, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will scan through an Array and compute
 * 				the average value of the array.
 *
 * Input: An integer to determine the size of the array.
 *
 * Output: The average value of the array.
 *  
 ******************************************************************/

import java.util.Scanner;

public class Array { 
	public static void main(String[]args) { 
		while (true){
		Scanner s = new Scanner(System.in); 
		System.out.println("What is the size of your array: "); 
		int size = s.nextInt(); 
		int[] myArray = new int [size]; 
		for (int i = 0; i < size; i++){ 
			myArray[i] = i; 
			} 
		double sum = 0; 
		double avg =0; 
		for (int i = 0; i < myArray.length; i++){ 
			sum += Double.valueOf(myArray[i]); 
			} 
		avg = sum/(myArray.length);
		System.out.println("The average of the array is: " + avg); 
		} 
	}
}