/******************************************************************
 * Program or Assignment #: Assignment1
 *
 * Programmer: Christine Ni
 *
 * Due Date: February 4, 2013
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will use a scanner class to print
 * 				the results of arithmetic expressions. We will 
 * 				take one integer and one double, then add them 
 * 				to get the results in integer form and then again 
 * 				to get results as a double. We will also multiply
 * 				the two numbers to get results in integer and
 * 				double form. 
 *
 * Input: One integer and one double. 
 *
 * Output:  Integer results of adding the two numbers, 
 * 			integer results of multiplying the two numbers, 
 * 			double results of adding the two numbers,
 * 			double results of multiplying the two numbers.
 *
 ******************************************************************/

import java.util.Scanner;

public class Numbers {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Input a number as an integer: ");
		int n1 = s.nextInt();
		System.out.println("Input a number as a double: ");
		double n2 = s.nextDouble();
			
		int resultAdd = 1;
		int resultMult = 0;
		double Add = 1;
		double Mult = 0;
				
		resultAdd = (int)n1 + (int)n2;
		resultMult = (int)n1 * (int)n2;
		Add = (double)n1 + (double)n2;
		Mult = (double)n1 * (double)n2;
		
		System.out.println("The integer result of the addition of the two numbers is: " + resultAdd);
		System.out.println("The integer result of the multiplication of the two numbers is: " + resultMult);
		System.out.println("The double result of the addition of the two numbers is: " + Add);
		System.out.println("The double result of the multiplication of the two numbers is: " + Mult);
	}

}