/******************************************************************
 * Program or Assignment #: Lab5
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 24, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will compute factorials using a for loop
 * 				and a while loop.
 *
 * Input: Two integers of value greater than 0.
 *
 * Output: Two factorial results from the two integers or an error 
 * 		   message if the integer(s) entered is less than or equal
 * 		   to 0.
 *  
 ******************************************************************/

import java.util.Scanner; 

public class Factorial {

	public static void main(String[] args) {
		Scanner s1 = new Scanner(System.in);
		System.out.println("Enter an integer of value greater than 0.");
		int pos1 = s1.nextInt();
		int fac1 = 1;   
	    for (int i=1; i<=pos1; i++) {
	    	fac1 = fac1*i;
	    }
	    System.out.println(fac1);
	    
	    Scanner s2 = new Scanner(System.in);
	    System.out.println("Enter another integer of value greater than 0.");
	    int pos2 = s2.nextInt();
	    int fac2 = 1;
	    while (pos2 > 0) { 
	    	fac2 = fac2 * pos2;
	    	pos2--;
	    	}
        System.out.println(fac2);
        
        if (pos1 <= 0  || pos2 <= 0) {
			System.out.println("ERROR: Number entered is less than or equal to 0");
        }
	}

}
