/******************************************************************
 * Program or Assignment #: Assignment2
 *
 * Programmer: Christine Ni
 *
 * Due Date: February 20, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will use booleans and conditionals to
 * 				print outputs that satisfies its respective conditions
 *
 * Input: A string of size 1-8
 *
 * Output: The program will print out a message containing "Error"
 * 		   if the user does not correctly input a string of size 1-8.
 * 		   The program will print out "(string) + " is a palindrome"", if the 
 * 		   input is a palindrome. If it is not a palindrome, the
 * 		   program will print "(string) + " is not a palindrome"".	   
 *
 ******************************************************************/

import java.util.Scanner;

public class Conditionals {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Input a string of size 1 to 8:");
		String s1 = s.nextLine();
		String s2 = "";
		
		if ((s1.length() < 1) || (s1.length() > 8)){
			System.out.println("Error: Enter a string of size 1 to 8");
		}
		else {			
			for (int i = s1.length()-1; i >= 0; i--) {
				s2 = s2+s1.charAt(i);
			}	
			if (s1.equalsIgnoreCase(s2)) {
				System.out.println(s1 + " is a Palindrome");	
			}
			else  { 						
				System.out.println(s1 + " is not a Palindrome");
			}
		}			
	}
}