/******************************************************************

 * Program or Assignment #: Assignment 4
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 19, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program asks the user to create a lab 
 * 				by creating different types of food and gerbils.
 * 				The user is then prompt to give a name for the 
 * 				food and the max amount that can be consumed daily.				
 * 				The gerbils are given an ID number and a name. The
 * 				program also asked how much of each food they ate
 * 				and if they bite or try escape. 
 * 				
 *
 * Input: Number of food items the gerbils eat
 * 		  Name of the food items
 * 		  Nax number that can be consumed per gerbil
 * 		  Number of gerbils in the lab
 * 		  Gerbers' ID number and name
 * 		  How much of each food items the gerbils eat
 * 		  Whether or not the gerbils bite or try to escape
 * 		  You can also ask the program to perform a search,
 * 		  calculate the average of each type of food each 
 * 		  gerbil ate, restart the program, or quit the program.
 *
 * Output: If you ask the program to perform a search, it will
 * 		   print all the information for the gerbil you entered.
 * 		   If you ask the program to calculate the average, it
 * 		   will print the average of each type of food the gerbils
 * 		   consumed.
 *

 ******************************************************************/

import java.util.Scanner;


public class Main {	
	public Gerbil[] gerbs;
	
	public static void main(String[] args){
		
		while(true){
		Scanner s = new Scanner(System.in);	
		System.out.println("How many food items do the gerbils eat?");
		Gerbil gerb = new Gerbil();
		gerb.setTypes(s.nextInt());
		gerb.food = new Food[gerb.types];
		
		for (int i = 0; i < gerb.types; i++){
			Food a = new Food();
			System.out.println("Name of food item " + (i+1) + ":" );
			Scanner s1 = new Scanner(System.in);
			a.name = s1.nextLine();
			System.out.println("Maximum amount that can be consumed per gerbil: ");
			Scanner s2 = new Scanner(System.in);
			a.maximumAmount = s2.nextInt();
			gerb.food[i] = new Food();
			gerb.food[i] = a;
		}
		System.out.println("How many gerbils are in the lab?");
		Scanner s3 = new Scanner(System.in);
		Gerbil ger = new Gerbil(); 
		ger.count = s3.nextInt();		
		Main m = new Main();
		m.gerbs = new Gerbil[ger.count];			
		for (int i = 0; i < ger.count; i++)	{
			m.gerbs[i] = new Gerbil();			
			System.out.println("What is gerbil "+(i+1)+"'s ID?");
			Scanner s4 = new Scanner(System.in);
			String id = s4.nextLine();
			m.gerbs[i].gid = id;
			
			for (int j = 0; j < id.length(); j++) {
				if (!Character.isLetterOrDigit(id.charAt(j))) {
					System.out.println("ID can only be a combination of numbers and letter. Please enter a new ID.");
					Scanner s5 = new Scanner(System.in);
					String id2 = s5.nextLine();
					m.gerbs[i].gid = id2;		
				}	
			}

			System.out.println("What is the gerbil's name?");
			Scanner s6 = new Scanner(System.in);
			m.gerbs[i].name = s6.nextLine();		
			m.gerbs[i].consumed = new int[gerb.types];
			m.gerbs[i].maxAmount = new int[gerb.food.length];
			
			for (int j = 0; j < gerb.food.length; j++) {
				System.out.println("How many " + gerb.food[j].name + " does " + m.gerbs[i].gid + " eat per day?");
				Scanner s7 = new Scanner(System.in);
				int ate = s7.nextInt();			
				 while (ate > gerb.food[j].maximumAmount) {
					System.out.println("Amount cannot exceed the max amount. Try again.");
					Scanner s8 = new Scanner(System.in);
					ate = s8.nextInt();					
				}
				m.gerbs[i].consumed[j] = ate;
				m.gerbs[i].maxAmount[j] = gerb.food[j].maximumAmount;
			}
			
			System.out.println("Does "+ m.gerbs[i].gid + " try to escape?");
			Scanner s11 = new Scanner(System.in);
			String es = s11.nextLine();
			while (!(es.equalsIgnoreCase("true") || es.equalsIgnoreCase("false"))) {
				System.out.println("Enter valid input");
				Scanner s12 = new Scanner(System.in);
				es = s12.nextLine();
			}
			if (es.equalsIgnoreCase("true"))
				m.gerbs[i].escapes = true;
			else
				m.gerbs[i].escapes = false;			
			
			System.out.println("Does " + m.gerbs[i].gid + " bite?");
			Scanner s9 = new Scanner(System.in);
			String bite = s9.nextLine();
		
			while (!(bite.equalsIgnoreCase("true") || bite.equalsIgnoreCase("false"))) {
				System.out.println("Enter valid input");
				Scanner s10 = new Scanner(System.in);
				bite = s10.nextLine();
			}
			if (bite.equalsIgnoreCase("true"))
				m.gerbs[i].bites = true;
			else
				m.gerbs[i].bites = false;
		}
		
			while(true) {
			System.out.println("\nWhat information would you like to know?");
			Scanner s13 = new Scanner(System.in);
			String info = s13.nextLine();			
			if (info.equalsIgnoreCase("average")) {
				String avg = m.averageFood();
				System.out.println(avg);
			}
					
			else if (info.equalsIgnoreCase("search")) {
				System.out.println("What is the lab ID of the gerbil you are searching for?");
				Scanner s14 = new Scanner(System.in);
				String sear = s14.next();
				Gerbil gerb2 = m.searchForGerbil(sear);
							
				if (gerb2.escapes)
					System.out.print(" (Will escape, ");
				else
					System.out.print(" (Will not escape, ");
				if (gerb2.bites)
					System.out.print("Will bite) \nFood: ");
				else
					System.out.print("Will not bite) \nFood: ");
				
				for (int j = 0; j < gerb2.consumed.length; j++){
					System.out.print(gerb.food[j].name + " - " + gerb2.consumed[j] + "/" + gerb2.maxAmount[j] + ", ");
				}
			}
			else if (info.equalsIgnoreCase("restart"))
			{
				break;
			}
			else if (info.equalsIgnoreCase("quit"))
			{
				System.exit(0);
			}
			else
			{
				System.out.println("ERROR: try again");
			}			
		}
		
		continue;
		}
	}
	
	private Gerbil searchForGerbil(String search) {
		
		for (int i = 0; i < gerbs.length; i++)
		{
			if (gerbs[i].gid.equalsIgnoreCase(search))
				return gerbs[i];
		}	
		
		return null;
	}

	public String averageFood()
	{
		String avgfood ="";
		
		for (int i = 0; i < gerbs.length; i++)
		{
			int eat = 0;
			int max = 0;
			for(int j = 0; j < gerbs[i].consumed.length; j++)
			{
				eat += gerbs[i].consumed[j];
				max += gerbs[i].maxAmount[j];
			}
			int avg = eat * 100 / max;
			
			avgfood += gerbs[i].gid + "(" + gerbs[i].name + ") " + avg + "%\n";
		}
		return avgfood;
	}
	
}
