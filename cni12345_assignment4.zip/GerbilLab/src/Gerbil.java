
public class Gerbil {
	

	public int types;
	public Food[] food;		

	public int getTypes() {
		return types;
	}

	public void setTypes(int types) {
		this.types = types;
	}
	
	public String gid;
	public String name;
	public boolean bites;
	public boolean escapes;
	public int[] consumed;
	public int[] maxAmount;
	public static int count;


}