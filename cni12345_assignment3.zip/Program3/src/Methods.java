/******************************************************************
 * Program or Assignment #: Assignment3
 *
 * Programmer: Christine Ni
 *
 * Due Date: March 26, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: The program asks the user to input a line of 
 * 				text. Then it will ask the user to choose a 
 * 				method of computation. The program will perform
 * 				the chosen method and then repeat the whole program
 * 				all over again. 
 *
 * Input: The user will input a line of text and choose a specific 
 * 		  method to perform.
 *
 * Output: Depending on the method chosen, the program will either
 * 		   return "(text) is a palindrome" or "(text) is not a palindrome",
 * 		   the rounded sum of doubles, the number of unique characters
 * 		   in the text, or the characters in the text reversed (but 
 * 		   maintaining the word order).
 * 
 * 
 ******************************************************************/

import java.util.Scanner;

public class Methods {
	public static void main(String[] args) {
		while(true) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter a line of text: ");
		String s1 = s.nextLine();
		
		System.out.println("Choose one of the following computations: ");
		System.out.println("Check if a palindrome");
		System.out.println("Compute the rounded sum");
		System.out.println("Count the unique characters");
		System.out.println("Reverse word characters");
		
		String n = s.nextLine();
		
		if (n.equals("Check if a palindrome")) { 
			if (isPalindrome(s1.toLowerCase()))
				System.out.println(s1 + " is a palindrome");
			else
				System.out.println(s1 + " is not a palindrome");
			}
		else if (n.equals("Compute the rounded sum")) {
				double sum = computeRoundedSum(s1);
				System.out.println("The rounded sum is " + sum);
			}	
		else if (n.equals("Count the unique characters")) {
				String unique = s1.toLowerCase();
				int characters = countUniqueCharacters(unique);
				System.out.println("There is/are " + characters + " unique characters.");		
			}	
		else if (n.equals("Reverse word characters")) {
				String r = reverseWordCharacters(s1);
				System.out.println(s1 + " in reverse is " + r);				
			}
		else {
				System.out.println("Error");
				}
			}
		}
	
	public static boolean isPalindrome(String pal) {
		if (pal.length() == 0 || pal.length() == 1)
			return true;
		if (pal.charAt(0) == pal.charAt(pal.length() - 1))
			return isPalindrome(pal.substring(1, pal.length() - 1));
			return false;
        }
	
	public static double computeRoundedSum(String round) {
	    String[] str = round.split(" ");
	    double[] doub = new double[str.length];

	    	for(int i = 0; i < doub.length; i++) { 
	    		double r = Double.parseDouble(str[i]);
	    		doub[i] = r;
	    		}
	    	double rSum = 0;
	    	for (int j = 0; j < doub.length; j++) {
	    		rSum = rSum + doub[j];
	    		}
	    	return Math.round(rSum);
			}
	
	public static int countUniqueCharacters(String uChar) {
		 int count = 0;
		    for (int k = 0; k < uChar.length(); k++) {
		        if (uChar.substring(0, k).contains(uChar.charAt(k) + ""));

		        else
		            count++;
		    	}
		    return count;
			}
	
	public static String reverseWordCharacters(String revWord) {
		String[] rev = revWord.split(" ");
		String invStr = " ";
		for (String rwc : rev){
		    String invWord = " ";
		    for (int l = rwc.length() - 1; l >= 0; l--)
		    invWord += rwc.charAt(l);
		    invStr += invWord;
		    invStr += " ";
				}
		return invStr.trim();
			}
	    
}
