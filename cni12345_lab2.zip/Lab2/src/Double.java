/******************************************************************
 * Program or Assignment #: Lab2
 *
 * Programmer: Christine Ni
 *
 * Due Date: April 21, 2014
 *
 * COMP110-002, Spring 2014       Instructor: Prof. Jay Aikat
 *
 * Pledge: I have neither given nor received unauthorized aid
 *         on this program. 
 *
 * Description: This program will ask the user to input two numbers
 * 				as double type using the Scanner class. The system
 * 				will then print the first number as an integer by 
 * 				type casting and print the second as the double, 
 * 				just as it was entered by the user.
 *
 * Input:  Two numbers of double type.
 *
 * Output:  The program will print the first double as an integer 
 * 			and the second as the same double that was in the input.
 *
 ******************************************************************/

import java.util.Scanner;

	public class Double {
		public static void main(String[] args) {
		
			Scanner s = new Scanner(System.in);
			
			System.out.println("Input two numbers of type double: ");
			double num1 = s.nextDouble();
			double num2 = s.nextDouble();
			
			System.out.println("The first double you entered is " + (num1) + "." + " It is " + (int)(num1) + " in the integer type.");
			System.out.println("The second double you entered is " + (double)(num2) + ".");
			
		}
}
